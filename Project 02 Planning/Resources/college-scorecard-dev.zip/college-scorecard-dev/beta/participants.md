##Participants in beta

###Requirements:
+ Have built things with open data
+ Serve target populations

###Proposed members
+ PJ Jue, CTO shop, Consumer Reports
+ Patrick Campbell, Students team, CFPB
+ Marina Martin, CTA, VA
+ TBD, TBD, CollegeBoard.com
+ Diana Adamson, CTO, ScholarMatch
+ James Sanders, Innovation, Kipp Schools
+ Sisi Wei, Dev lead, ProPublica
+ TBD, TBD, Noodle
+ TBD, TBD, StartClass
+ TBD, TBD, Project Greenlight
+ TBD, TBD, Niche.com
+ TBD, TBD, Princeton Review
