##Goals of beta period

1. Test out API and data sets to identify any problems with data, documentation, or tech.
2. Build a working feedback loop between the data producers and data users.
3. Make improvements based on the most critical problems.
4. At least 5 products made by external groups are ready to launch by launch day.
