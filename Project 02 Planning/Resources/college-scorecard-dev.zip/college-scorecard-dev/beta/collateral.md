

- [ ] Disclosure agreement doc https://github.com/18F/college-choice/issues/237
- [ ] Listserv
- [ ] Data experts for listserv (Data helpdesk?)
- [ ] Invite email
- [x] Overview doc
