#

+ July 29th
  + Erie invites participants via email
+ July 31st
  + Participants have all turned in paperwork
+ August 4
  + Data access is given to the group
  + Github access is given to the group
  + Group listserv starts
+ August 17th
  + WIP demo day, beta participants get PICC, Ed and WH feedback
+ August 31st
  + Final demo day, beta participants are thanked for feedback about data
  + Any products/teams that are appropriate for further amplication go into vet
+ September 4th
  + Invitations go out for any appropriate product release
+ September 14th
  + Release date for any appropriate products
  + Data is released
  + Group listerv is opened to the public
